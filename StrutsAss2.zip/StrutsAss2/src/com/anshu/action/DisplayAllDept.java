package com.anshu.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.anshu.dao.DepartDaoImp;
import com.anshu.dao.UserDaoImpl;
import com.anshu.form.Department;
import com.anshu.form.User;

public class DisplayAllDept extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Department dept=(Department) form;
			
				request.setAttribute("department",new DepartDaoImp().getAllDepartments());
				
		System.out.println("hello");
			return mapping.findForward("success");
		
      }
}
 


