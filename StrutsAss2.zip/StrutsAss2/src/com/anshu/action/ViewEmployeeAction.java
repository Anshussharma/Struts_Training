package com.anshu.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.anshu.dao.EmployeeDaoImpl;
import com.anshu.form.Department;

public class ViewEmployeeAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Department d=(Department)form;
		
		request.setAttribute("employeelist", new EmployeeDaoImpl().getEmployeeByDept(d.getDname()));
		return mapping.findForward("success");
	}

}
