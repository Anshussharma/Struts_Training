package com.anshu.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.anshu.dao.EmployeeDaoImpl;
import com.anshu.form.Employee;

public class EmployeeByNameAction  extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Employee e=(Employee)form;
		String ename= request.getParameter("ename");
		
		Employee emp=new EmployeeDaoImpl().getEmployeeByName(e.getEname());
		request.setAttribute("employees",emp);
		if(emp==null){
			return mapping.findForward("fail");
		}
		return mapping.findForward("success");
	}

}
