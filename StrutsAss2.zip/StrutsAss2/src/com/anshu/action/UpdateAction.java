package com.anshu.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.anshu.dao.EmployeeDaoImpl;
import com.anshu.form.Employee;


public class UpdateAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		Employee us=(Employee)form;
		new EmployeeDaoImpl().updateEmployee(new Employee(us.getEid(),us.getEname(),us.getDeptid(),us.getSalary(),us.getDesignation(),us.getEmail(), us.getMgrid()),us.getEid());
		 request.setAttribute("employees", new EmployeeDaoImpl().getAllEmployee());
		    return mapping.findForward("success");
	}

}
