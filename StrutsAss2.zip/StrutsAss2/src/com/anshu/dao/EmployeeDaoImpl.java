package com.anshu.dao;
import com.anshu.form.*;

import java.sql.*;
import java.util.*;
public class EmployeeDaoImpl implements EmployeeDao {

	public List<Employee> getAllEmployee() throws SQLException{
		List<Employee> employees=new ArrayList<Employee>();
		Connection conn= ConnectionMaster.getConnection();
		Statement st= conn.createStatement();
		ResultSet rs= st.executeQuery("select * from employee");
		while(rs.next()){
			employees.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4), rs.getString(5),rs.getString(6) , rs.getInt(7)));
		}
		//employees.stream().forEach(e->System.out.println(e));
		return employees;
	}
	

	@Override
	public Employee getEmployeeById(int eid) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn= ConnectionMaster.getConnection();
		PreparedStatement st= conn.prepareStatement("select * from employee where eid=?");
		
		st.setInt(1,eid);
		Employee e1=null;
		ResultSet rs=st.executeQuery();
		if(rs.next()){
			 e1 = new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4), rs.getString(5),rs.getString(6) , rs.getInt(7));
		    
		}
		return e1;
	
	}
	 public void addEmployee(Employee employee) throws SQLException{
		 Connection conn=ConnectionMaster.getConnection();
		 PreparedStatement pst=conn.prepareStatement("insert into employee (eid , ename, deptid, salary, designation, email, mgrid) value(?,?,?,?,?,?,?)");
		 pst.setInt(1, employee.getEid());
		 pst.setString(2, employee.getEname());
		 pst.setInt(3, employee.getDeptid());
		 pst.setInt(4, employee.getSalary());
		 pst.setString(5, employee.getDesignation());
		 pst.setString(6, employee.getEmail());
		 pst.setInt(7, employee.getMgrid());
		 pst.executeUpdate();
	}


	@Override
	public void updateEmployee( Employee employee, int eid) throws SQLException {
		Connection conn=ConnectionMaster.getConnection();
		String query="update employee set eid=?, ename=?, deptid=?, salary=?, designation=?, email=?, mgrid=? where eid="+eid+"";
		PreparedStatement pst=conn.prepareStatement(query);
		//pst.setInt(1, eid);
		 pst.setInt(1, employee.getEid());
		 pst.setString(2, employee.getEname());
		 pst.setInt(3, employee.getDeptid());
		 pst.setInt(4, employee.getSalary());
		 pst.setString(5, employee.getDesignation());
		 pst.setString(6, employee.getEmail());
		 pst.setInt(7, employee.getMgrid());
		pst.executeUpdate();
	
		
	}

    
	@Override
	public List<Employee> getEmployeeByDept(String dname) throws SQLException {
		// TODO Auto-generated method stub
		List<Employee> employeesbydept=new ArrayList<Employee>();
		Connection conn= ConnectionMaster.getConnection();
		Statement st= conn.createStatement();
		String query="select * from employee e join department d on d.deptid=e.deptid where d.dname = '"+dname+"'";
		ResultSet rs= st.executeQuery(query);
		
		while(rs.next()){
			employeesbydept.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4), rs.getString(5),rs.getString(6) , rs.getInt(7)));
		}
		//employeesbydept.stream().forEach(e->System.out.println(e));
		return employeesbydept;
	}


	@Override
	public List<Employee> getEmployeeByManager(String ename) throws SQLException {
		// TODO Auto-generated method stub
		List<Employee> employees=new ArrayList<Employee>();
		Connection conn= ConnectionMaster.getConnection();
		Statement st= conn.createStatement();
		String query="select * from employee where mgrid=(select eid from employee where ename ='"+ ename +"')";
		ResultSet rs= st.executeQuery(query);
		
		while(rs.next()){
			employees.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4), rs.getString(5),rs.getString(6) , rs.getInt(7)));
		}
		//employees.stream().forEach(e->System.out.println(e));
		return employees;
	}


	@Override
	public List<Employee> getAllManagers() throws SQLException {
		List<Employee> employees=new ArrayList<Employee>();
		Connection conn= ConnectionMaster.getConnection();
		Statement st= conn.createStatement();
		ResultSet rs= st.executeQuery("select * from employee where eid in (select mgrid from employee)");
		while(rs.next()){
			employees.add( new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4), rs.getString(5),rs.getString(6) , rs.getInt(7)));
		}
		//employees.stream().forEach(e->System.out.println(e));
		return employees;
	}
    
	public Employee getEmployeeByName(String ename) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn= ConnectionMaster.getConnection();
		
		String query="select * from employee where ename='"+ename+"'";
		
		PreparedStatement st= conn.prepareStatement(query);
		
		Employee e1=null;
		ResultSet rs=st.executeQuery();
		if(rs.next()){
			
			 e1 = new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4), rs.getString(5),rs.getString(6) , rs.getInt(7));
		    
		}
		
		return e1;
	}


	@Override
	public void deleteEmployee(int eid) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn=ConnectionMaster.getConnection();
		 
		PreparedStatement pst=conn.prepareStatement("delete from employee where eid=?");
		pst.setInt(1, eid);
		pst.executeUpdate();
	
	}


	
	
	 
}
