package com.anshu.dao;

import java.sql.SQLException;
import java.util.List;

import com.anshu.form.Department;

public interface DepartDao {
  public List<Department> getAllDepartments() throws SQLException;
  public Department getDeptById(int deptid) throws SQLException;
  public void addDepartment(Department d) throws SQLException;
  public void delectDepartment(int deptid) throws SQLException;
  public void updateDepartment(String city,int deptid) throws SQLException;
  
}
