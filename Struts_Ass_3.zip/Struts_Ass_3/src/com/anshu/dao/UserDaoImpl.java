package com.anshu.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.anshu.form.User;

public class UserDaoImpl implements UserDao{

	@Override
	public List<User> getAllUser() throws SQLException {
		// TODO Auto-generated method stub
		List<User> user=new ArrayList<User>();
		Connection conn= ConnectionMaster.getConnection();
		Statement st= conn.createStatement();
		ResultSet rs= st.executeQuery("select * from user");
		while(rs.next()){
			user.add(new User(rs.getString(1),  rs.getString(2)));
		}
		//employees.stream().forEach(e->System.out.println(e));
		return user;
	}

}
