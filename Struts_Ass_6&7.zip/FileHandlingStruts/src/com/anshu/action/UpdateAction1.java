package com.anshu.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.anshu.dao.EmployeeDaoImpl;
import com.anshu.form.Employee;
import com.anshu.form.UserDelete;

public class UpdateAction1 extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		Employee user=(Employee)form;
		request.setAttribute("employee", new EmployeeDaoImpl().getEmployeeById(id));
		Employee e=new EmployeeDaoImpl().getEmployeeById(user.getEid());
		System.out.println(e);
		return mapping.findForward("success");
	}

}
