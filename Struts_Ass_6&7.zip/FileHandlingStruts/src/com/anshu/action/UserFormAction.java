package com.anshu.action;

import java.io.ByteArrayInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import com.anshu.form.UserForm;

public class UserFormAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		UserForm user=(UserForm)form;
		 FormFile file=user.getFile();
	        String s1="";
	        ByteArrayInputStream stream=(ByteArrayInputStream)file.getInputStream();
	        
	        int i=0;
	        
	        while((i=stream.read())!=-1) {
	            s1=s1+(char)i;
	        }
	        
	        request.setAttribute("data", s1);
	        return mapping.findForward("success");
	}

}
