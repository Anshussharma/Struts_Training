package com.anshu.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.anshu.dao.EmployeeDaoImpl;
import com.anshu.form.Employee;

public class MyDispatchAction extends DispatchAction{




    public ActionForward add(ActionMapping mapping, ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
    	Employee us=(Employee)form;
		 new EmployeeDaoImpl().addEmployee(new Employee(us.getEid(),us.getEname(),us.getDeptid(),us.getSalary(),us.getDesignation(),us.getEmail(), us.getMgrid()));
		    request.setAttribute("employees", new EmployeeDaoImpl().getAllEmployee());
		    return mapping.findForward("success");
    }
    public ActionForward update(ActionMapping mapping, ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
    	Employee us=(Employee)form;
		new EmployeeDaoImpl().updateEmployee(new Employee(us.getEid(),us.getEname(),us.getDeptid(),us.getSalary(),us.getDesignation(),us.getEmail(), us.getMgrid()),us.getEid());
		 request.setAttribute("employees", new EmployeeDaoImpl().getAllEmployee());
		    return mapping.findForward("success");
        
    }
    public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
    	Employee us=(Employee)form;
    	new EmployeeDaoImpl().deleteEmployee(us.getEid());
	    request.setAttribute("employees", new EmployeeDaoImpl().getAllEmployee());
	    return mapping.findForward("success");
        
    }
    public ActionForward next(ActionMapping mapping, ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
    	Employee us=(Employee)form;
    	//Employee employees = new EmployeeDaoImpl().getEmployeeById(us.getEid());
    	int id=us.getEid()+1;
	    request.setAttribute("employees", new EmployeeDaoImpl().getEmployeeById(id));
	    return mapping.findForward("success");
        
    }
    public ActionForward prev(ActionMapping mapping, ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
    	Employee us=(Employee)form;
    	int id=us.getEid()+1;
    	 request.setAttribute("employees", new EmployeeDaoImpl().getEmployeeById(id));
 	    return mapping.findForward("success");
        
    }


}