package com.anshu.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.anshu.dao.EmployeeDaoImpl;
import com.anshu.dao.UserDaoImpl;
import com.anshu.form.User;

public class UserAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		User user=(User)form;
		List<User> al=new ArrayList<User>();
		al= new UserDaoImpl().getAllUser();
		boolean isSuccess=false;
		for(int i=0;i<al.size();i++){
			if(al.get(i).getUsername().equals(user.getUsername()) && al.get(i).getPassword().equals(user.getPassword())){
				request.setAttribute("employees",new EmployeeDaoImpl().getAllEmployee());
				isSuccess=true;
				break;
				
			}
			else{
				isSuccess=false;
				
			}
		}
		if(isSuccess==true){
			return mapping.findForward("success");
		}
		else{
			return mapping.findForward("failure");
		}
      }
}
