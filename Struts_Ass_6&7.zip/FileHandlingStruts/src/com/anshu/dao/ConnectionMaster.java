package com.anshu.dao;
import java.sql.*;
public class ConnectionMaster {
    
    public static Connection getConnection() {
        Connection conn=null;
        try {
             Class.forName("com.mysql.cj.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/springdata" , "root" ,"62630295");
             
             
         }catch(SQLException ex) {System.out.print(ex.getMessage());}catch(ClassNotFoundException ex) {System.out.print(ex.getMessage());}
        return conn;
    }
    



}
