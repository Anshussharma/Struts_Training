package com.anshu.tags;

import java.util.Calendar;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class FibonacciTag extends TagSupport{
   public static int getFibo(int n){
	   if(n==1 || n==2)
		   return 1;
	   else
		   return getFibo(n-1)+getFibo(n-2);
   }
   private int number;
public FibonacciTag() {
	super();
	// TODO Auto-generated constructor stub
}
public FibonacciTag(int number) {
	super();
	this.number = number;
}
public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
@Override
public int doStartTag() throws JspException {
	// TODO Auto-generated method stub
	JspWriter out=pageContext.getOut();
	try{
		out.print(FibonacciTag.getFibo(number));
	}catch(Exception ex){}
	return EVAL_PAGE;
}


}
