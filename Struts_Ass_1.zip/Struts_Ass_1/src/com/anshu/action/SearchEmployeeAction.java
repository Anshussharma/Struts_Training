package com.anshu.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.anshu.daoImpl.AllEmployeesDaoImpl;
import com.anshu.daoImpl.SearchEmployeeDaoImpl;
import com.anshu.form.Employee;

public class SearchEmployeeAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		List<Employee> employees;
		try {
			employees = new SearchEmployeeDaoImpl().searchEmployee((Employee)form);
			request.setAttribute("employees", employees);
			return mapping.findForward("allEmployees");
		} catch (Exception ex) {
			System.out.print(ex.getMessage());
			return mapping.findForward("failure");
		}
	}
}
