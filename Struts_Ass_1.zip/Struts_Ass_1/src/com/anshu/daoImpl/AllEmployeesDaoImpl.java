package com.anshu.daoImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.anshu.form.Employee;

public class AllEmployeesDaoImpl {
	
	public List<Employee> getAllEmployee() throws SQLException {
		List<Employee> employees=new ArrayList<Employee>();
		Connection con=ConnectionMaster.getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("SELECT * FROM employee");
		
		while(rs.next()) {
			employees.add(new Employee(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getInt(5)));
		}
		return employees;
	}
}
