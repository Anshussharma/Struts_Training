package com.anshu.exception;

public class EmailNotValidException   extends RuntimeException{
    
    private String message;
    
    public EmailNotValidException() {}
    public EmailNotValidException(String message) {this.message=message;}
    
    
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    
    



}
