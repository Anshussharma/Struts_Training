package com.anshu.action;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.anshu.dao.EmployeeDaoImpl;
import com.anshu.form.Employee;

public class AddAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Employee us=(Employee)form;
		 new EmployeeDaoImpl().addEmployee(new Employee(us.getEid(),us.getEname(),us.getDeptid(),us.getSalary(),us.getDesignation(),us.getEmail(), us.getMgrid()));
		    request.setAttribute("employees", new EmployeeDaoImpl().getAllEmployee());
		    return mapping.findForward("success");
	}

}
